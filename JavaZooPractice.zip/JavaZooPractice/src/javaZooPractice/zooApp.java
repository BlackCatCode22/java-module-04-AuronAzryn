import java.io.*;
import java.util.*;

// 🔹 Abstract base class for all animals
abstract class Animal {
    protected String name;
    protected int age;
    protected String gender;
    protected String birthSeason;
    protected String color;
    protected int weight;
    protected String origin;

    // Constructor to set all animal details
    public Animal(String name, int age, String gender, String birthSeason,
                  String color, int weight, String origin) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.birthSeason = birthSeason;
        this.color = color;
        this.weight = weight;
        this.origin = origin;
    }

    // Every subclass will return its own species name
    public abstract String getSpecies();

    // Format how each animal is printed in the report
    @Override
    public String toString() {
        return getSpecies() + ": " + name + ", Age: " + age + " years, " + gender +
                ", Born in: " + birthSeason + ", Color: " + color + ", Weight: " +
                weight + " lbs, Origin: " + origin;
    }
}

// 🔹 Subclasses for each species
class Hyena extends Animal {
    public Hyena(String name, int age, String gender, String birthSeason,
                 String color, int weight, String origin) {
        super(name, age, gender, birthSeason, color, weight, origin);
    }
    public String getSpecies() { return "Hyena"; }
}

class Lion extends Animal {
    public Lion(String name, int age, String gender, String birthSeason,
                String color, int weight, String origin) {
        super(name, age, gender, birthSeason, color, weight, origin);
    }
    public String getSpecies() { return "Lion"; }
}

class Tiger extends Animal {
    public Tiger(String name, int age, String gender, String birthSeason,
                 String color, int weight, String origin) {
        super(name, age, gender, birthSeason, color, weight, origin);
    }
    public String getSpecies() { return "Tiger"; }
}

class Bear extends Animal {
    public Bear(String name, int age, String gender, String birthSeason,
                String color, int weight, String origin) {
        super(name, age, gender, birthSeason, color, weight, origin);
    }
    public String getSpecies() { return "Bear"; }
}

// 🔹 Main class for reading data, processing it, and writing the output
public class zooApp {

    public static void main(String[] args) {
        String inputFile = "arrivingAnimals.txt";   // input data file
        String outputFile = "newAnimals.txt";       // output report file

        // Predefined names for each animal in order
        List<String> hyenaNames = Arrays.asList("Shenzi", "Banzai", "Ed", "Kamari");
        List<String> lionNames = Arrays.asList("Simba", "Nala", "Mufasa", "Sarabi");
        List<String> tigerNames = Arrays.asList("Rajah", "Shere Khan", "Tora", "Sundar");
        List<String> bearNames = Arrays.asList("Baloo", "Kenai", "Koda", "Winnie");

        // Counters to assign names in order
        int hyenaCount = 0, lionCount = 0, tigerCount = 0, bearCount = 0;

        // Store all animals in one list
        ArrayList<Animal> animals = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;

            // 🔁 Read the file line by line
            while ((line = br.readLine()) != null) {
                // Split the line into chunks separated by commas
                String[] parts = line.split(", ");

                // Extract key details from each line
                int age = Integer.parseInt(parts[0].split(" ")[0]);
                String gender = parts[0].contains("female") ? "Female" : "Male";
                String species = parts[0].toLowerCase().contains("hyena") ? "hyena" :
                        parts[0].toLowerCase().contains("lion") ? "lion" :
                                parts[0].toLowerCase().contains("tiger") ? "tiger" : "bear";
                String birthSeason = parts[1].replace("born in ", "");
                String color = parts[2].replace("color", "").trim();
                int weight = Integer.parseInt(parts[3].split(" ")[0]);
                String origin = parts[4].replace("from ", "");

                // 🐆 Create the correct subclass based on species
                switch (species) {
                    case "hyena":
                        animals.add(new Hyena(hyenaNames.get(hyenaCount++), age, gender, birthSeason, color, weight, origin));
                        break;
                    case "lion":
                        animals.add(new Lion(lionNames.get(lionCount++), age, gender, birthSeason, color, weight, origin));
                        break;
                    case "tiger":
                        animals.add(new Tiger(tigerNames.get(tigerCount++), age, gender, birthSeason, color, weight, origin));
                        break;
                    case "bear":
                        animals.add(new Bear(bearNames.get(bearCount++), age, gender, birthSeason, color, weight, origin));
                        break;
                }
            }

            // 📊 Count how many of each species were processed
            Map<String, Integer> speciesCount = new HashMap<>();
            for (Animal a : animals) {
                speciesCount.put(a.getSpecies(), speciesCount.getOrDefault(a.getSpecies(), 0) + 1);
            }

            // 📝 Write the formatted animal data into the output file
            BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
            bw.write("New Animals Report:\n\n");
            for (Animal a : animals) {
                bw.write(a.toString() + "\n");
            }

            // 📊 Write species totals at the end
            bw.write("\nTotal Counts:\n");
            for (String sp : speciesCount.keySet()) {
                bw.write(sp + ": " + speciesCount.get(sp) + "\n");
            }
            bw.close();

            System.out.println("✅ newAnimals.txt created successfully!");

        } catch (IOException e) {
            System.out.println("❌ Error reading or writing file: " + e.getMessage());
        }
    }
}
