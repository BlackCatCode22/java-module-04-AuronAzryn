package com.alex.zoo;

public class zooApp {
    public static void main(String[] args) {
        System.out.println("Welcome to my Zoo Keeper Challenge Project!\n");

        // create a new animal!
        Animal myNewAnimal = new Animal();

        System.out.println("\n myNewAnimal object's aniID is: " + myNewAnimal.getAniID());

        myNewAnimal.setAniID("acd123");
        System.out.println("\n The setAniID() method was called: \n");

        System.out.println("\n myNewAnimal object's aniID is: " + myNewAnimal.getAniID());


    }
}